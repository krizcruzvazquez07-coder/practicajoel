<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php
// $products = [
//     ['id' => 1, 'name' => 'Coca600ml', 'description' => 'Coca cola de 600 grs', 'price' => 18.00],
//     ['id' => 2, 'name' => 'Coca1lt', 'description' => 'Coca cola de 1 litro', 'price' => 38.00],
// ];
?>
    <div class="container">
        <div class="row my-4 mx-1">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="mb-0">Productos</h1>
                <button class="btn btn-primary btn-sm" onclick="execute('/productos/agregar')">
                    <i class="bi bi-plus"></i>
                    <span class="d-none d-sm-inline">Agregar</span>
                </button>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="table-responsive">
                <table id="myTable" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Imagen</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th class="text-end text-nowrap w-auto">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
    <script>
        $('#myTable').DataTable({
            serverSide: true,
            processing: true,
            ajax: {
                url: '<?php echo e(route("products.data")); ?>',
                type: 'GET'
            },
            columns: [
                {
                    data: 'image',
                    orderable: false,
                    searchable: false,
                    width: '80px'
                },
                { data: 'name' },
                { data: 'description' },
                { data: 'price' },
                {
                    data: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            pageLength: 10, // Items por página
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
            // language: {
            //     url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json' // Opcional: español
            // }
        });

        function execute(url) {
            window.open(url, '_self');
        }
        function deleteRecord(url) {
            if (confirm('¿Está seguro de eliminar este registro?')) {
                $('<form>', {'action': url, 'method': 'POST'})
                .append($('<input>', {type: 'hidden', name: '_token', value: '<?php echo e(csrf_token()); ?>'}))
                .append($('<input>', {type: 'hidden', name: '_method', value: 'DELETE'}))
                .appendTo('body')
                .submit()
                .remove();
            }
        }
        // Obtener de la sessión el mensaje de éxito o error
        <?php if(session('success')): ?>
            alert (`<?php echo e(session('success')); ?>`);
            // Opcional: Recarga la tabla después de agregar/eliminar
            // $('#myTable').DataTable().ajax.reload(null, false); // false para no resetear paginación
        <?php endif; ?>
    </script>
    <?php $__env->stopSection(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\webapps\laravel\practica7joel\resources\views\products\index.blade.php ENDPATH**/ ?>