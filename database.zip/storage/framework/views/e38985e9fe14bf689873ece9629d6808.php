<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <h1 class="mb-4">Agregar / Editar usuario</h1>

        <form class="row g-3 needs-validation" novalidate method="POST" action="<?php echo e(url('/users')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e(isset($user) ? $user->id : ''); ?>">

            <div class="col-md-6">
                <label for="name" class="form-label">Nombre</label>
                <input type="text" class="form-control <?php echo e($errors->has('name')? 'is-invalid' : ''); ?>" id="name" name="name" required maxlength="255" value="<?php echo e(old('name', $user->name ?? '')); ?>">
                <div class="invalid-feedback">
                     <?php echo e($errors->has('name')? $errors->first('name') : 'Campo requerido'); ?>

                </div>
            </div>

            <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control <?php echo e($errors->has('email')? 'is-invalid' : ''); ?>" id="email" name="email" required maxlength="255" value="<?php echo e(old('email', $user->email ?? '')); ?>">
                <div class="invalid-feedback">
                     <?php echo e($errors->has('email')? $errors->first('email') : 'Campo requerido'); ?>

                </div>
            </div>

            <div class="col-md-6">
                <label for="password" class="form-label">Contraseña</label>
                <input type="password" class="form-control <?php echo e($errors->has('password')? 'is-invalid' : ''); ?>" id="password" name="password" <?php echo e(isset($user) ? '' : 'required'); ?> minlength="8">
                <div class="invalid-feedback">
                     <?php echo e($errors->has('password')? $errors->first('password') : (isset($user) ? 'Dejar en blanco para mantener la contraseña' : 'Campo requerido')); ?>

                </div>
            </div>

            <div class="col-md-6">
                <label for="password_confirmation" class="form-label">Confirmar Contraseña</label>
                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" <?php echo e(isset($user) ? '' : 'required'); ?> minlength="8">
            </div>

            <div class="col-12">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>

    </div>

    <?php $__env->startSection('js'); ?>
    <script>
    (() => {
        'use strict'
        const forms = document.querySelectorAll('.needs-validation')
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
    })()
    </script>
    <?php $__env->stopSection(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\webapps\laravel\practica7joel\resources\views\users\form.blade.php ENDPATH**/ ?>