<style>
    .menu-card:hover {
        box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175);
        transition: box-shadow 0.2s;
        cursor: pointer;
    }
</style>
<div class="card menu-card" onclick="<?php echo e($funToDo); ?>">
    <div class="card-body text-center">
        <img src="<?php echo e($imgPath); ?>" width="60px" height="60px" class="d-block mx-auto rounded-circle"
            alt="imagen de <?php echo e($cardTitle); ?>" />
        <h4 class="card-title"><?php echo e($cardTitle); ?></h4>
        <p class="card-text"><?php echo e($cardDescr); ?></p>
    </div>
</div>

<script></script>
<?php /**PATH C:\webapps\laravel\practica7joel\resources\views\components\menu-card.blade.php ENDPATH**/ ?>