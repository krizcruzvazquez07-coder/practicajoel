<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('messages.Welcome')); ?></div>

                <div class="card-body">
                    <?php if(auth()->guard()->guest()): ?>
                        <h4>Bienvenido invitado!!!</h4>
                        
                        <p class="mt-4">Aquí puedes acceder a la información de contenido público</p>
                    <?php else: ?>
                        <h4>¡Hola, <?php echo e(Auth::user()->name); ?> !</h4>
                        <p class="mb-4">Has iniciado sesión correctamente.</p>
                        <p class="mb-4">En breve serás redireccionado...</p>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary"><?php echo e(__('Ir al Menú Principal')); ?></a>
                    <?php endif; ?>
                </div>
            </div>

            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .gap-3 {
        gap: 1rem;
    }
    .d-flex {
        display: flex;
    }
    .card {
        transition: all 0.3s ease;
    }
    .card:hover {
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
<?php if(auth()->guard()->check()): ?>
    // redireccinar a home en 5 segs
    setTimeout(function() {
        window.location.href = "<?php echo e(route('home')); ?>";
    }, 2000);
<?php endif; ?>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\webapps\laravel\practica7joel\resources\views/welcome-simple.blade.php ENDPATH**/ ?>