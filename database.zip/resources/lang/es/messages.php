<?php
return [
    'Welcome' => 'Bienvenido',
    'Login' => 'Iniciar sesión',
    'Logout' => 'Cerrar sesión',
];
