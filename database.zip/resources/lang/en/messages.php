<?php
return [
    'Welcome' => 'You are welcome',
    'Login' => 'Login',
    'Logout' => 'Logout',
];
